<div id="header">
    <a href="<?php echo $this->baseUrl ?>admin"><img alt="The Social Goods" src="<?php echo $this->baseUrl ?>public/images/logo_header.png" align="center";/></a>
    
    <div id="menucontainer">
        <div id="menuitem" class="blackmenu">
            <a href="<?php echo $this->baseUrl ?>items/new">Add New Items</a>
        </div>
        <div id="menuitem" class="blackmenu">
            <a href="<?php echo $this->baseUrl ?>items/admin">Edit Items</a>
        </div>
    </div>
</div>